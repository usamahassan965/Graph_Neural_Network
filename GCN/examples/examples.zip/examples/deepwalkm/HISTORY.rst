.. :changelog:

History
-------

1.0.3 (2018-03-23)
---------------------

* Now compatible with the latest version of gensim and sklearn
* Better support for Python 3

1.0.2 (2014-09-19)
---------------------

* Fixed gensim at 0.10.2 for now

1.0.1 (2014-09-19)
---------------------

* Added utilities to support generated embeddings for larger graphs
* Support for additional input file formats

1.0.0 (2014-08-24)
---------------------

* First release on PyPI.

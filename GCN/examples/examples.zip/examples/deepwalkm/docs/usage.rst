========
Usage
========

To use DeepWalk in a project::

	import deepwalk